#!/bin/sh
cp ../../../../../../YASMF/YASMF-Next/dist/yasmf.js .
cp ../../../../../../YASMF/YASMF-Next/dist/yasmf.css .
cp -r ../../../../../../YASMF/YASMF-Next/dist/yasmf-assets .
echo "Ready."
